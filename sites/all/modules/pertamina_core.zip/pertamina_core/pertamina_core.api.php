<?php

function get_jenis_bbm_array(){
    $ArrayJenisBbm = array();
    if (function_exists('create_array_from_view')){
        $ArrayJenisBbm = create_array_from_view('data_jenis_bbm');
    }
    return $ArrayJenisBbm;
}

function get_penjualan_bbm_by_date($date1 = null, $date2 = null){
    $ArrayPenjualan = array();
    if (!empty($date1) && !empty($date2)){
        $filter = array();
        $filter[0]['filtername'] = 'field_tanggal_mulai_value';
        $filter[0]['filtervalue'] = array(
            'min' => $date1,
            'max' => $date2,
        );
        $ArrayPenjualan = create_array_from_view('data_penjualan', null, $filter);
    }
    return $ArrayPenjualan;
}